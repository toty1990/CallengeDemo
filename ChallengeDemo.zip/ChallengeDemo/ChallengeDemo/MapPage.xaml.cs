﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Geolocation;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Maps;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace ChallengeDemo
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MapPage : Page
    {
        public MapPage()
        {
            this.InitializeComponent();
        }
        private void MapControl_Loaded(object sender,RoutedEventArgs e )
        {
            MapControl.Center = new Geopoint(new BasicGeoposition()
            {
               Latitude = 47.604 , Longitude=-122.329 
            });
            MapControl.ZoomLevel = 12;
        }
        private void TrafficCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            MapControl.TrafficFlowVisible = true; 
        }

        private void TrafficCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            MapControl.TrafficFlowVisible = false;
        }

        private void MapStyleButton_Click(object sender, RoutedEventArgs e)
        {
            if (MapControl.Style == Windows.UI.Xaml.Controls.Maps.MapStyle.Aerial)
            {
                MapControl.Style = Windows.UI.Xaml.Controls.Maps.MapStyle.Road;
            }
            else
            {
                MapControl.Style = Windows.UI.Xaml.Controls.Maps.MapStyle.Aerial;
                MapStyleButton.Content = "Road";
            }
        }
        private async void MapControl_MapTapped(Windows.UI.Xaml.Controls.Maps.MapControl sender, Windows.UI.Xaml.Controls.Maps.MapInputEventArgs args)
        {
            var tappedGeoposition = args.Location.Position;
            string status = $"Map Tapped at \nLatitude:{tappedGeoposition.Latitude} " +
            $"\nLongitude : {tappedGeoposition.Longitude}";

            var messageDialog = new MessageDialog(status);
            await messageDialog.ShowAsync();
        }
           
           
    }
}
